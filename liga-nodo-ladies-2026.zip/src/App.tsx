import React, { useState, useEffect } from 'react';
import { Player, ResultRecord, NextFixture, DateSchedule, Category, DateId, ResultType, ComputedPlayerRanking, PublicLeagueData } from './types';
import { INITIAL_NEXT_FIXTURE, INITIAL_PLAYERS, INITIAL_RESULTS, INITIAL_DATES_SCHEDULE } from './data/initialSeed';
import { computeRankingsForCategory } from './utils/points';
import { Header } from './components/Header';
import { NextFixtureCard } from './components/NextFixtureCard';
import { RankingTable } from './components/RankingTable';
import { PlayerDetailModal } from './components/PlayerDetailModal';
import { NotificationSubscribeModal } from './components/NotificationSubscribeModal';
import { AdminModal } from './components/AdminModal';
import { Footer } from './components/Footer';
import { RefreshCw } from 'lucide-react';

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<Category>('8va');
  const [players, setPlayers] = useState<Player[]>(INITIAL_PLAYERS);
  const [results, setResults] = useState<ResultRecord[]>(INITIAL_RESULTS);
  const [nextFixture, setNextFixture] = useState<NextFixture>(INITIAL_NEXT_FIXTURE);
  const [datesSchedule, setDatesSchedule] = useState<DateSchedule[]>(INITIAL_DATES_SCHEDULE);
  const [subscribersCount, setSubscribersCount] = useState<number>(0);
  const [subscribers, setSubscribers] = useState<any[]>([]);

  const [selectedPlayerRanking, setSelectedPlayerRanking] = useState<ComputedPlayerRanking | null>(null);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Load data from server
  const fetchLeagueData = async () => {
    try {
      const res = await fetch('/api/data');
      if (res.ok) {
        const data: PublicLeagueData = await res.json();
        setPlayers(data.players || []);
        setResults(data.results || []);
        setNextFixture(data.nextFixture || INITIAL_NEXT_FIXTURE);
        setDatesSchedule(data.datesSchedule || INITIAL_DATES_SCHEDULE);
        setSubscribersCount(data.subscribersCount || 0);
      }
    } catch (err) {
      console.warn('Using client memory fallback:', err);
    } finally {
      setIsLoading(false);
    }
  };

  // Fetch admin subscribers if logged in
  const fetchSubscribers = async () => {
    try {
      const res = await fetch('/api/subscribers');
      if (res.ok) {
        const data = await res.json();
        setSubscribers(data.subscribers || []);
      }
    } catch (err) {
      console.error('Error fetching subscribers:', err);
    }
  };

  useEffect(() => {
    fetchLeagueData();
    // Check session storage for admin login
    const savedAuth = sessionStorage.getItem('nodo_admin_auth');
    if (savedAuth === 'nodo-admin-auth-valid') {
      setIsAdminLoggedIn(true);
      fetchSubscribers();
    }
  }, []);

  // Admin Login Handler
  const handleAdminLogin = async (pin: string): Promise<boolean> => {
    try {
      const res = await fetch('/api/admin/auth', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pin }),
      });

      if (res.ok) {
        setIsAdminLoggedIn(true);
        sessionStorage.setItem('nodo_admin_auth', 'nodo-admin-auth-valid');
        fetchSubscribers();
        return true;
      }
    } catch (err) {
      console.error('Login error:', err);
    }
    return false;
  };

  // Add Player Handler (a)
  const handleAddPlayer = async (player: { name: string; lastName: string; category: Category }) => {
    try {
      const res = await fetch('/api/players', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(player),
      });

      if (res.ok) {
        await fetchLeagueData();
        return true;
      }
    } catch (err) {
      console.error('Add player error:', err);
    }
    return false;
  };

  // Delete Player Handler
  const handleDeletePlayer = async (id: string) => {
    try {
      const res = await fetch(`/api/players/${id}`, {
        method: 'DELETE',
      });

      if (res.ok) {
        await fetchLeagueData();
        return true;
      }
    } catch (err) {
      console.error('Delete player error:', err);
    }
    return false;
  };

  // Save Result Handler (b)
  const handleSaveResult = async (result: { playerId: string; dateId: DateId; resultType: ResultType }) => {
    try {
      const res = await fetch('/api/results', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(result),
      });

      if (res.ok) {
        await fetchLeagueData();
        return true;
      }
    } catch (err) {
      console.error('Save result error:', err);
    }
    return false;
  };

  // Delete Result Handler
  const handleDeleteResult = async (id: string) => {
    try {
      const res = await fetch(`/api/results/${id}`, {
        method: 'DELETE',
      });

      if (res.ok) {
        await fetchLeagueData();
        return true;
      }
    } catch (err) {
      console.error('Delete result error:', err);
    }
    return false;
  };

  // Update Fixture Handler (c)
  const handleUpdateFixture = async (fixture: NextFixture) => {
    try {
      const res = await fetch('/api/fixture', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(fixture),
      });

      if (res.ok) {
        await fetchLeagueData();
        return true;
      }
    } catch (err) {
      console.error('Update fixture error:', err);
    }
    return false;
  };

  // Update Dates Schedule Handler
  const handleUpdateDatesSchedule = async (newSchedule: DateSchedule[]) => {
    try {
      const res = await fetch('/api/dates-schedule', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ datesSchedule: newSchedule }),
      });

      if (res.ok) {
        await fetchLeagueData();
        return true;
      }
    } catch (err) {
      console.error('Update dates schedule error:', err);
    }
    return false;
  };

  // Bulk Import Handler
  const handleBulkImport = async (data: { players: any[]; results?: any[]; mode?: string }) => {
    try {
      const res = await fetch('/api/admin/bulk-import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (res.ok) {
        await fetchLeagueData();
        return await res.json();
      }
    } catch (err) {
      console.error('Bulk import error:', err);
    }
    return null;
  };

  // Change Admin PIN Handler
  const handleChangePin = async (currentPin: string, newPin: string) => {
    try {
      const res = await fetch('/api/admin/pin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentPin, newPin }),
      });

      const data = await res.json();
      return { success: res.ok && data.success, error: data.error };
    } catch (err) {
      return { success: false, error: 'Error de conexión con el servidor' };
    }
  };

  // Subscribe Handler
  const handleSubscribe = async (phone: string, name: string) => {
    try {
      const res = await fetch('/api/subscribers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, name }),
      });

      if (res.ok) {
        await fetchLeagueData();
        if (isAdminLoggedIn) fetchSubscribers();
        return true;
      }
    } catch (err) {
      console.error('Subscribe error:', err);
    }
    return false;
  };

  // Compute Rankings for Current Category
  const categoryRankings = computeRankingsForCategory(players, results, selectedCategory);

  return (
    <div className="min-h-screen bg-[#1F3D37] text-white font-['Nunito',sans-serif] flex flex-col justify-between selection:bg-[#c6f135] selection:text-[#1F3D37]">
      {/* Header with Category Switcher & Admin trigger */}
      <Header
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        onOpenAdmin={() => setIsAdminOpen(true)}
        isAdminLoggedIn={isAdminLoggedIn}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full max-w-[440px] mx-auto">
        {/* Next Fixture Card */}
        <NextFixtureCard
          fixture={nextFixture}
          onOpenNotifications={() => setIsNotificationOpen(true)}
          subscribersCount={subscribersCount}
        />

        {/* Ranking Table */}
        {isLoading ? (
          <div className="py-12 text-center text-white/50 text-xs font-semibold flex items-center justify-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin text-[#c6f135]" />
            <span>Cargando ranking de la liga...</span>
          </div>
        ) : (
          <RankingTable
            rankings={categoryRankings}
            category={selectedCategory}
            onSelectPlayer={(p) => setSelectedPlayerRanking(p)}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenAdmin={() => setIsAdminOpen(true)}
        isAdminLoggedIn={isAdminLoggedIn}
      />

      {/* Player Detail Modal */}
      <PlayerDetailModal
        playerRanking={selectedPlayerRanking}
        onClose={() => setSelectedPlayerRanking(null)}
      />

      {/* WhatsApp & Browser Notifications Modal */}
      <NotificationSubscribeModal
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
        onSubscribe={handleSubscribe}
      />

      {/* Administration Modal */}
      <AdminModal
        isOpen={isAdminOpen}
        onClose={() => setIsAdminOpen(false)}
        isAdminLoggedIn={isAdminLoggedIn}
        onLogin={handleAdminLogin}
        players={players}
        results={results}
        nextFixture={nextFixture}
        datesSchedule={datesSchedule}
        onAddPlayer={handleAddPlayer}
        onDeletePlayer={handleDeletePlayer}
        onSaveResult={handleSaveResult}
        onDeleteResult={handleDeleteResult}
        onUpdateFixture={handleUpdateFixture}
        onUpdateDatesSchedule={handleUpdateDatesSchedule}
        onBulkImport={handleBulkImport}
        onChangePin={handleChangePin}
        subscribers={subscribers}
      />
    </div>
  );
}
