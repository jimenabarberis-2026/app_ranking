import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import { INITIAL_PLAYERS, INITIAL_RESULTS, INITIAL_NEXT_FIXTURE, INITIAL_DATES_SCHEDULE } from './src/data/initialSeed.js';

interface LeagueStorage {
  players: any[];
  results: any[];
  nextFixture: any;
  datesSchedule: any[];
  adminPin: string;
  subscribers: any[];
}

const PORT = 3000;
const DATA_DIR = path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'nodo_league_data.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Load or initialize data
function loadLeagueData(): LeagueStorage {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      return {
        players: parsed.players || INITIAL_PLAYERS,
        results: parsed.results || INITIAL_RESULTS,
        nextFixture: parsed.nextFixture || INITIAL_NEXT_FIXTURE,
        datesSchedule: parsed.datesSchedule || INITIAL_DATES_SCHEDULE,
        adminPin: parsed.adminPin || '1234',
        subscribers: parsed.subscribers || [],
      };
    }
  } catch (err) {
    console.error('Error loading league data file, initializing default:', err);
  }

  const initialData: LeagueStorage = {
    players: INITIAL_PLAYERS,
    results: INITIAL_RESULTS,
    nextFixture: INITIAL_NEXT_FIXTURE,
    datesSchedule: INITIAL_DATES_SCHEDULE,
    adminPin: '1234',
    subscribers: [],
  };

  saveLeagueData(initialData);
  return initialData;
}

function saveLeagueData(data: LeagueStorage) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving league data:', err);
  }
}

let db = loadLeagueData();

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // --- API ROUTES ---

  // Health check
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({ status: 'ok', league: 'Liga NODO Ladies 2026' });
  });

  // Get public league data (without admin pin)
  app.get('/api/data', (req: Request, res: Response) => {
    res.json({
      players: db.players,
      results: db.results,
      nextFixture: db.nextFixture,
      datesSchedule: db.datesSchedule || INITIAL_DATES_SCHEDULE,
      subscribersCount: db.subscribers.length,
    });
  });

  // Admin auth check
  app.post('/api/admin/auth', (req: Request, res: Response) => {
    const { pin } = req.body;
    if (pin === db.adminPin) {
      res.json({ success: true, token: 'nodo-admin-auth-valid' });
    } else {
      res.status(401).json({ success: false, error: 'Código PIN incorrecto' });
    }
  });

  // Update admin PIN
  app.post('/api/admin/pin', (req: Request, res: Response) => {
    const { currentPin, newPin } = req.body;
    if (currentPin !== db.adminPin) {
      return res.status(401).json({ success: false, error: 'PIN actual incorrecto' });
    }
    if (!newPin || newPin.trim().length < 4) {
      return res.status(400).json({ success: false, error: 'El nuevo PIN debe tener al menos 4 dígitos' });
    }
    db.adminPin = newPin.trim();
    saveLeagueData(db);
    res.json({ success: true, message: 'PIN actualizado con éxito' });
  });

  // Bulk Import Players & Results from Excel
  app.post('/api/admin/bulk-import', (req: Request, res: Response) => {
    const { players: importedPlayers, results: importedResults, mode } = req.body;

    if (!Array.isArray(importedPlayers)) {
      return res.status(400).json({ success: false, error: 'Formato de importación inválido' });
    }

    if (mode === 'replace') {
      db.players = [];
      db.results = [];
    }

    let addedPlayersCount = 0;
    let addedResultsCount = 0;

    importedPlayers.forEach((p: any) => {
      if (!p.name || !p.lastName || !p.category) return;
      const cleanCat = ['8va', '7ma', '6ta'].includes(p.category) ? p.category : '8va';

      // Check if player already exists by name/lastName/category
      let existing = db.players.find(
        (x) =>
          x.name.toLowerCase().trim() === p.name.toLowerCase().trim() &&
          x.lastName.toLowerCase().trim() === p.lastName.toLowerCase().trim() &&
          x.category === cleanCat
      );

      if (!existing) {
        existing = {
          id: 'p_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
          name: p.name.trim(),
          lastName: p.lastName.trim(),
          category: cleanCat,
          createdAt: new Date().toISOString(),
        };
        db.players.push(existing);
        addedPlayersCount++;
      }

      // If imported object has result attached (e.g. F1, F2, F3)
      if (p.results && typeof p.results === 'object') {
        Object.keys(p.results).forEach((dateKey) => {
          const dateId = dateKey.toUpperCase();
          if (['F1', 'F2', 'F3', 'F4', 'F5', 'F6'].includes(dateId)) {
            const resultType = p.results[dateKey];
            if (['P', 'SF', 'F', 'C'].includes(resultType)) {
              const resIndex = db.results.findIndex((r) => r.playerId === existing.id && r.dateId === dateId);
              if (resIndex >= 0) {
                db.results[resIndex].resultType = resultType;
              } else {
                db.results.push({
                  id: 'r_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
                  playerId: existing.id,
                  dateId,
                  resultType,
                  updatedAt: new Date().toISOString(),
                });
                addedResultsCount++;
              }
            }
          }
        });
      }
    });

    if (Array.isArray(importedResults)) {
      importedResults.forEach((r: any) => {
        if (r.playerId && ['F1', 'F2', 'F3', 'F4', 'F5', 'F6'].includes(r.dateId) && ['P', 'SF', 'F', 'C'].includes(r.resultType)) {
          const resIndex = db.results.findIndex((x) => x.playerId === r.playerId && x.dateId === r.dateId);
          if (resIndex >= 0) {
            db.results[resIndex].resultType = r.resultType;
          } else {
            db.results.push({
              id: 'r_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
              playerId: r.playerId,
              dateId: r.dateId,
              resultType: r.resultType,
              updatedAt: new Date().toISOString(),
            });
            addedResultsCount++;
          }
        }
      });
    }

    saveLeagueData(db);
    res.json({
      success: true,
      addedPlayersCount,
      addedResultsCount,
      totalPlayers: db.players.length,
      totalResults: db.results.length,
    });
  });

  // Update Dates Schedule
  app.post('/api/dates-schedule', (req: Request, res: Response) => {
    const { datesSchedule } = req.body;
    if (!Array.isArray(datesSchedule)) {
      return res.status(400).json({ success: false, error: 'Lista de fechas no válida' });
    }

    db.datesSchedule = datesSchedule;
    saveLeagueData(db);
    res.json({ success: true, datesSchedule: db.datesSchedule });
  });

  // Add new player (a)
  app.post('/api/players', (req: Request, res: Response) => {
    const { name, lastName, category } = req.body;
    if (!name || !lastName || !['8va', '7ma', '6ta'].includes(category)) {
      return res.status(400).json({ success: false, error: 'Datos incompletos o categoría inválida' });
    }

    const newPlayer = {
      id: 'p_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      name: name.trim(),
      lastName: lastName.trim(),
      category,
      createdAt: new Date().toISOString(),
    };

    db.players.push(newPlayer);
    saveLeagueData(db);

    res.json({ success: true, player: newPlayer });
  });

  // Delete player
  app.delete('/api/players/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    db.players = db.players.filter((p) => p.id !== id);
    db.results = db.results.filter((r) => r.playerId !== id);
    saveLeagueData(db);
    res.json({ success: true });
  });

  // Add or update result per date (b)
  app.post('/api/results', (req: Request, res: Response) => {
    const { playerId, dateId, resultType } = req.body;

    if (!playerId || !['F1', 'F2', 'F3', 'F4', 'F5', 'F6'].includes(dateId) || !['P', 'SF', 'F', 'C'].includes(resultType)) {
      return res.status(400).json({ success: false, error: 'Resultado o fecha no válidos' });
    }

    const playerExists = db.players.some((p) => p.id === playerId);
    if (!playerExists) {
      return res.status(404).json({ success: false, error: 'La participante no existe' });
    }

    // Check if result already exists for this player and date
    const existingIndex = db.results.findIndex((r) => r.playerId === playerId && r.dateId === dateId);

    if (existingIndex >= 0) {
      db.results[existingIndex] = {
        ...db.results[existingIndex],
        resultType,
        updatedAt: new Date().toISOString(),
      };
    } else {
      const newResult = {
        id: 'r_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        playerId,
        dateId,
        resultType,
        updatedAt: new Date().toISOString(),
      };
      db.results.push(newResult);
    }

    saveLeagueData(db);
    res.json({ success: true });
  });

  // Delete result
  app.delete('/api/results/:id', (req: Request, res: Response) => {
    const { id } = req.params;
    db.results = db.results.filter((r) => r.id !== id);
    saveLeagueData(db);
    res.json({ success: true });
  });

  // Update next fixture (c)
  app.post('/api/fixture', (req: Request, res: Response) => {
    const { dateText, timeText, venueText, notes } = req.body;
    if (!dateText || !timeText || !venueText) {
      return res.status(400).json({ success: false, error: 'Completa todos los campos obligatorios de la fecha' });
    }

    db.nextFixture = {
      dateText: dateText.trim(),
      timeText: timeText.trim(),
      venueText: venueText.trim(),
      notes: notes ? notes.trim() : '',
      updatedAt: new Date().toISOString(),
    };

    saveLeagueData(db);
    res.json({ success: true, nextFixture: db.nextFixture });
  });

  // Subscribe to WhatsApp notifications
  app.post('/api/subscribers', (req: Request, res: Response) => {
    const { phone, name } = req.body;
    if (!phone || phone.trim().length < 8) {
      return res.status(400).json({ success: false, error: 'Ingresa un número de celular válido' });
    }

    const cleanPhone = phone.trim().replace(/\s+/g, '');
    const existing = db.subscribers.find((s) => s.phone === cleanPhone);

    if (!existing) {
      db.subscribers.push({
        id: 'sub_' + Date.now(),
        phone: cleanPhone,
        name: name ? name.trim() : '',
        createdAt: new Date().toISOString(),
      });
      saveLeagueData(db);
    }

    res.json({ success: true, count: db.subscribers.length });
  });

  // Get subscribers (Admin)
  app.get('/api/subscribers', (req: Request, res: Response) => {
    res.json({ subscribers: db.subscribers });
  });

  // --- VITE MIDDLEWARE / STATIC SERVING ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
